function avg_ellipse_gray = analyze_ellipse_consistency()
    % 加载聚类结果
    load('./cluster_results/clustering_results.mat', 'results');
    
    % 提取第一个视频片段的5次尝试数据
    segment1_attempts = results(1).Attempts;
    [height, width] = size(segment1_attempts{1}, 2:3); % 获取图像尺寸
    
    % 初始化累积矩阵 (用于记录椭圆区域出现频次)
    total_ellipse_count = zeros(height, width);
    
    % ========== 遍历5次尝试 ==========
    for t = 1:5
        % 提取当前尝试的第一帧数据
        frame_data = squeeze(segment1_attempts{t}(1, :, :, :));
        
        % 解析颜色聚类标签
        [unique_colors, ~, color_labels] = unique(reshape(frame_data, [], 3), 'rows');
        color_labels = reshape(color_labels, height, width);
        
        % 检测最佳椭圆区域
        best_mask = detect_single_ellipse(color_labels, height, width);
        
        % 累积椭圆区域出现次数
        total_ellipse_count = total_ellipse_count + double(best_mask);
    end
    
    % ========== 生成灰度图 ==========
    avg_ellipse_gray = total_ellipse_count / 5;  % 归一化到[0,1]
    
    % ========== 可视化结果 ==========
    figure('Position', [100, 100, 800, 400]);
    
    % 显示平均灰度图
    subplot(1,2,1);
    imshow(avg_ellipse_gray, 'Colormap', gray);
    colorbar;
    title('五次尝试椭圆区域平均分布 (0=黑, 1=白)');
    
    % 显示二值化阈值图 (阈值=0.2)
    subplot(1,2,2);
    imshow(avg_ellipse_gray >= 0.2);
    title('出现频次≥2次的稳定区域');
end

function best_mask = detect_single_ellipse(color_labels, height, width)
    % 初始化输出
    best_mask = false(height, width);
    best_score = -inf;
    
    % 遍历所有颜色聚类块
    for k = 1:max(color_labels(:))
        cluster_mask = (color_labels == k);
        
        % 区域过滤
        stats = regionprops(cluster_mask, 'Area', 'Eccentricity', 'Solidity');
        if isempty(stats) || stats.Area < 100 || stats.Eccentricity > 0.95 || stats.Solidity < 0.9
            continue;
        end
        
        % 椭圆评分 (可根据需要调整权重)
        current_score = stats.Area * (1 - stats.Eccentricity) * stats.Solidity;
        
        % 更新最佳区域
        if current_score > best_score
            best_score = current_score;
            best_mask = cluster_mask;
        end
    end
end
