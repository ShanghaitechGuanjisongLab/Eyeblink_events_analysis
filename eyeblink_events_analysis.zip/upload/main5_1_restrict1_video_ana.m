%% 确定蓝光的峰值
figure; plot(blueData);

[peaks,locs] = findpeaks(blueData,'MinPeakHeight',230,'MinPeakDistance',400); % 修改114


%作图确认
figure;plot(blueData);
hold on;
plot(locs,peaks,'x','MarkerSize',10);

%创建分组
for i = 1:(length(locs)-1)
    slot0{i}.eye_area(1,:) = eye_data(locs(i):(locs(i)+480)); %根据视频fps和trace interval修改480
    slot0{i}.frame = locs(i):(locs(i)+480);
    slot0{i}.time_onset = [0:1/30:16];
end

% 作图确认
figure; plot(slot0{1}.time_onset,slot0{1}.eye_area);


% for i = 1:(length(locs)-1)
%     slot{i}.eye_area(1,:) = eye_data(locs(i):(locs(i)+435));
%     slot{i}.frame = locs(i):(locs(i)+435);
%     slot{i}.time_onset = [0:1/30:14.5];
% end

%% 增强版 - 带闭眼动作标记 (严格模式+新增需求)
numCells = length(slot0);
cellsPerFigure = 16;
numFigures = ceil(numCells/cellsPerFigure);

% 参数设置
minPeakProminence = 30;   % 最小突显度阈值
minPeakDistance = 10;     % 最小峰间距（数据点）
thresholdRatio = 1.5;       % 标准差比例系数（新增参数） 
minTimeInterval = 0.5;      % 最小时间间隔（秒）
outputData = cell(numCells, 1);

for figIdx = 1:numFigures
    figure('Units','normalized','Position',[0.1 0.1 0.8 0.8]);
    startCell = (figIdx-1)*cellsPerFigure + 1;
    endCell = min(figIdx*cellsPerFigure, numCells);

    for subIdx = 1:(endCell-startCell+1)
        cellNum = startCell + subIdx - 1;
        subplot(4,4,subIdx);

        % 提取数据
        time = slot0{cellNum}.time_onset;
        area = slot0{cellNum}.eye_area;

        % 计算统计量（新增标准差计算）
        z_area = mode(area);
        error_area = std(area);  % 新增标准差计算
        threshold = z_area - error_area * thresholdRatio;  % 修改阈值公式

        % 绘制主曲线
        plot(time, area, 'b-', 'LineWidth', 1.5);
        title(sprintf('Cell %d\nThr:%.1f', cellNum, threshold), 'FontSize', 10);
        xlabel('Time (s)', 'FontSize', 8);
        ylabel('Eye Area', 'FontSize', 8);
        grid on;
        xlim([0 16]);

        % 绘制众数参考线
        hold on;
        yline(z_area, '--', 'Color', [1 0.5 0], 'LineWidth', 2);
        hold off;

        % 检测候选点
        [~, minLocs] = findpeaks(-area, 'MinPeakProminence', minPeakProminence,...
            'MinPeakDistance', minPeakDistance);

        % 筛选阶段1：阈值筛选
        validIdx = area(minLocs) < threshold;
        candidateLocs = minLocs(validIdx);
        candidateTimes = time(candidateLocs);
        candidateAreas = area(candidateLocs);

        % 筛选阶段2：时间间隔筛选（新增邻近点条件判断）
        [sortedTimes, sortIdx] = sort(candidateTimes);
        sortedAreas = candidateAreas(sortIdx);
        selectedIdx = true(1, length(sortedTimes));

        lastTime = -inf;
        for k = 1:length(sortedTimes)
            currentTime = sortedTimes(k);
            
            % 新增条件：仅当两个点都<14.5时才进行邻近检测
            if (currentTime < 14.5) && (lastTime < 14.5) 
                if currentTime - lastTime < minTimeInterval
                    % 比较纵坐标大小
                    if sortedAreas(k) < sortedAreas(k-1)
                        selectedIdx(k-1) = false;
                    else
                        selectedIdx(k) = false;
                    end
                else
                    lastTime = currentTime;
                end
            else
                % 任一点>=14.5时不进行邻近筛选
                lastTime = currentTime;
            end
        end

        % 最终筛选结果
        finalLocs = candidateLocs(sortIdx(selectedIdx));
        finalTimes = time(finalLocs);
        finalAreas = area(finalLocs);

        % 存储输出数据
        outputData{cellNum} = finalTimes(finalTimes < 15);

        % 可视化标记（保持不变）
        if ~isempty(finalTimes)
            hold on;
            plot(finalTimes, finalAreas, 'ro',...
                'MarkerSize', 8, 'LineWidth', 1.5);
            yRange = max(area) - min(area);
            for j = 1:length(finalTimes)
                textY = finalAreas(j) - yRange*0.05;
                text(finalTimes(j), textY,...
                    sprintf('%.1f', finalTimes(j)),...
                    'Color', 'red',...
                    'FontSize', 10,...
                    'HorizontalAlignment', 'center',...
                    'VerticalAlignment', 'top');
            end
            hold off;
        end
    end

    % 调整子图间距
    ha = findobj(gcf,'type','axes');
    set(ha, 'FontSize', 8);
end
