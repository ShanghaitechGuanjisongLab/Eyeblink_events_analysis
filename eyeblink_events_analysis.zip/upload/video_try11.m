clc; clear; close all;
addpath(genpath(pwd));

%% 参数设置
video_path = './dataset3/angle00_01_cropped3.avi';
output_folder = './cluster_results';
mkdir(output_folder);
binary_image = visualize_best_ellipse('./cluster_results_base/clustering_results_base_mouse1_cropped3.mat');

%% 视频读取配置
video = VideoReader(video_path);
total_frames = video.NumFrames;
[image_size_x, image_size_y] = deal(video.Height, video.Width);

%% 超参数配置
layer_num = 2;
unit_iter = 20;
sub_iter = 20;
try_num = 5;
MaxIter = 500;
size_weight_list = [8 2];
final_n = [4];
z_weight = 1;

frame_unit_num = 25 * image_size_x * image_size_y;
v1 = (frame_unit_num / final_n)^(1/5);
n_list = [];
n2 = final_n;
for k = 1:layer_num
    n_list = [n2, n_list];
    n2 = n2 * v1;
end
unit_kernel_num_list = [8 2];

%% 计算视频片段
segment_overlap = 0;
segment_length = 25;
start_frames = 1:(segment_length-segment_overlap):(total_frames-segment_length+1);
num_segments = length(start_frames);

%% 初始化存储结构
results = struct(...
    'SegmentNumber', {}, ...
    'StartFrame', {}, ...
    'EndFrame', {}, ...
    'Attempts', {});


binary_image = double(binary_image);
base_image = binary_image;
base_edge = 1;
for k = -base_edge:base_edge
    for r = -base_edge:base_edge
        base_image(base_edge+1+k:end-base_edge+k,base_edge+1+r:end-base_edge+r) = base_image(base_edge+1+k:end-base_edge+k,base_edge+1+r:end-base_edge+r) + binary_image(base_edge+1:end-base_edge,base_edge+1:end-base_edge);
    end
end

%% 主处理循环
fprintf('总视频片段数: %d\n', num_segments); % 进度条1/3：总进度
tic;
for seg_idx = 1:num_segments
    current_start = start_frames(seg_idx);
    current_end = current_start + segment_length - 1;
    
    %% 进度条2/3：片段进度
    fprintf('\n[进度] 正在处理片段 %d/%d (帧%d-%d)\n', seg_idx, num_segments, current_start, current_end);
    
    %% 读取当前片段
    data_raw = zeros(segment_length, image_size_x, image_size_y, 3);
    for i = 1:segment_length
        data_raw(i, :, :, :) = im2double(read(video, current_start + i - 1));
    end

    %% 构建特征矩阵
    unit_list_all = [];
    for z = 1:segment_length
        frame_data = squeeze(data_raw(z, :, :, :));
        for k = 1:image_size_x
            for r = 1:image_size_y
                if base_image(k,r) > 0.5
                    unit1 = [k r z*z_weight reshape(frame_data(k, r, :)*255, [1,3])];
                    unit_list_all = [unit_list_all; unit1];
                end
            end
        end
    end
    unit_list_all(:,6) = 0*unit_list_all(:,6);
    
    %% 聚类处理
    all_attempts = cell(1, try_num);
    for t = 1:try_num
        %% 进度条3/3：尝试进度
        fprintf('  尝试 %d/%d...', t, try_num);
        
        temp_all = zeros(segment_length, image_size_x, image_size_y, 3);
        cluster_ids_all = zeros(size(unit_list_all,1), layer_num);
        unit_data_a = unit_list_all;
        unit_data_a(:, 1:3) = unit_data_a(:, 1:3)/25*32;
        
        for s = 1:layer_num
            unit_kernel_num = unit_kernel_num_list(s);
            unit_data_a(:, 1:3) = unit_data_a(:, 1:3) * size_weight_list(s);
            
            min_error = inf;
            for k = 1:round(unit_iter/sub_iter)
                parfor r = 1:sub_iter
                    [idx_k, unit_cluster_center_k, ~, recons_unit1_k] = ...
                        kmeansWithError(unit_data_a, unit_kernel_num, MaxIter);
                    error_list(r) = sum(sum((unit_data_a - recons_unit1_k).^2));
                    idx_list{r} = idx_k;
                    unit_center_list{r} = unit_cluster_center_k;
                    recons_unit1_list{r} = recons_unit1_k;
                end
                
                [min_error_r, no1] = min(error_list);
                if min_error_r < min_error
                    min_error = min_error_r;
                    idxa = idx_list{no1};
                    unit_center = unit_center_list{no1};
                    recons_unit = recons_unit1_list{no1};
                end
            end
            
            cluster_ids_all(:, s) = idxa;
            color_lista = round(unit_center(:, 4:6));
            for k = 1:size(unit_list_all,1)
                z = round(unit_list_all(k, 3)/z_weight);
                temp_all(z, unit_list_all(k,1), unit_list_all(k,2), :) = color_lista(idxa(k),:)/255;
            end
            unit_data_a(:, 1:3) = recons_unit(:, 1:3)/size_weight_list(s);
        end
        
        final_cluster_map = zeros(segment_length, image_size_x, image_size_y, 'uint16');
        ptr = 1;
        for z = 1:segment_length
            for x = 1:image_size_x
                for y = 1:image_size_y
                    if base_image(x,y) > 0.5
                        final_cluster_map(z,x,y) = cluster_ids_all(ptr, end);
                        ptr = ptr + 1;
                    end
                end
            end
        end
        
        all_attempts{t} = struct('Reconstructed', temp_all, 'ClusterIDs', final_cluster_map);
        fprintf('完成 (耗时%.1fs)\n', toc); % 添加时间反馈
    end
    
    %% 保存结果
    results(seg_idx).SegmentNumber = seg_idx;
    results(seg_idx).StartFrame = current_start;
    results(seg_idx).EndFrame = current_end;
    results(seg_idx).Attempts = all_attempts;
end

%% 保存最终结果
save(fullfile(output_folder, 'clustering_results2.mat'), 'results', '-v7.3');
fprintf('\n全部处理完成！总耗时%.1f秒\n', toc);
