function VideoPlayer
    % 创建主界面
    fig = uifigure('Name', '简单视频播放器', 'Position', [100 100 800 600]);
    
    % 创建视频显示区域
    ax = uiaxes(fig, 'Position', [50 100 700 400]);
    
    % 创建进度条
    slider = uislider(fig,...
        'Position', [50 80 700 3],...
        'ValueChangedFcn', @(src,event) sliderMoved());
    
    % 创建播放/暂停按钮
    playBtn = uibutton(fig, 'push',...
        'Position', [350 50 100 30],...
        'Text', '播放',...
        'ButtonPushedFcn', @(btn,event) playButtonPushed());

    % 初始化变量
    videoFile = '.\dataset2\mouse1_cropped.avi';  % 请替换为你的视频文件路径
    % final_video_with_convex.avi
    % mouse1_cropped2.avi
    vidObj = [];
    isPlaying = false;
    timerObj = timer();
    
    % 初始化视频
    function initVideo
        vidObj = VideoReader(videoFile);
        slider.Limits = [0 vidObj.Duration];
        showFrame(0);
    end

    % 显示指定时间的帧
    function showFrame(time)
        vidObj.CurrentTime = time;
        frame = readFrame(vidObj);
        imshow(frame, 'Parent', ax);
        slider.Value = time;
    end

    % 进度条回调函数
    function sliderMoved
        if ~isPlaying
            showFrame(slider.Value);
        end
    end

    % 播放按钮回调函数
    function playButtonPushed
        if isPlaying
            % 暂停播放
            stop(timerObj);
            isPlaying = false;
            playBtn.Text = '播放';
        else
            % 开始播放
            isPlaying = true;
            playBtn.Text = '暂停';
            
            % 设置定时器
            timerObj = timer(...
                'ExecutionMode', 'fixedRate',...
                'Period', 0.1,...
                'TimerFcn', @updateFrame);
            
            start(timerObj);
        end
    end

    % 定时器回调函数
    function updateFrame(~,~)
        if vidObj.CurrentTime < vidObj.Duration
            frame = readFrame(vidObj);
            imshow(frame, 'Parent', ax);
            slider.Value = vidObj.CurrentTime;
        else
            % 播放结束
            stop(timerObj);
            isPlaying = false;
            playBtn.Text = '播放';
            showFrame(0);
        end
    end

    % 初始化并启动
    initVideo
    
    % 清理函数
    fig.CloseRequestFcn = @(src,event) closeFigure;
    
    function closeFigure
        if isvalid(timerObj)
            stop(timerObj);
            delete(timerObj);
        end
        delete(fig);
    end
end