% 创建VideoReader对象，替换为你的视频路径
video = VideoReader('mouse1_cropped2.avi'); 

% 创建图形窗口
figure('Name','Video Player','NumberTitle','off');

% 循环播放每一帧
while hasFrame(video)
    % 读取当前帧
    frame = readFrame(video);
    
    % 显示帧
    imshow(frame);
    
    % 根据帧率控制播放速度
    pause(1/video.FrameRate); 
end

% 播放完成提示
disp('视频播放结束');