function VideoAnalyzer
% 创建主界面
fig = uifigure('Name', '视频分析工具', 'Position', [100 100 1200 800]);

% 视频显示区域
ax = uiaxes(fig, 'Position', [50 300 800 450]);

% 控制面板
controlPanel = uipanel(fig, 'Position', [50 50 1100 200]);

% 文件选择组件
uilabel(controlPanel, 'Text','视频文件:', 'Position',[20 150 60 20]);
filePathLabel = uilabel(controlPanel, 'Position',[90 150 400 20], 'Text', '未选择文件');
uibutton(controlPanel, 'push',...
    'Position', [500 145 150 30],...
    'Text', '选择文件_select file',...
    'ButtonPushedFcn', @selectFile);

% 播放控制组件
playBtn = uibutton(controlPanel, 'push',...
    'Position', [20 100 80 30],...
    'Text', '播放_play',...
    'ButtonPushedFcn', @playControl);

stopBtn = uibutton(controlPanel, 'push',...
    'Position', [120 100 80 30],...
    'Text', '停止_pause',...
    'ButtonPushedFcn', @stopVideo);

timeSlider = uislider(controlPanel,...
    'Position', [220 110 600 3],...
    'Limits', [0 1],...
    'ValueChangedFcn', @sliderMoved);

% ROI控制组件
roiBtn = uibutton(controlPanel, 'push',...
    'Position', [20 50 100 30],...
    'Text', '设置ROI_set ROI',...
    'ButtonPushedFcn', @setROI,...
    'Enable', 'off');

exportBtn = uibutton(controlPanel, 'push',...
    'Position', [125 50 125 30],...
    'Text', '导出数据_export data',...
    'ButtonPushedFcn', @exportData,...
    'Enable', 'off');

statusLabel = uilabel(controlPanel,...
    'Position', [260 50 400 30],...
    'Text', '就绪');

% 初始化变量
videoPath = '';
vidObj = [];
isPlaying = false;
timerObj = [];
currentFrame = [];
roiRect = [];
blueData = [];
originalVideoTime = 0;
roiPlot = [];
hWait = [];
frameRate = 0;

% 文件选择回调
    function selectFile(~,~)
        [file, path] = uigetfile({'*.avi;*.mp4;*.mov','视频文件'},'选择视频文件');
        if file == 0, return; end

        videoPath = fullfile(path, file);
        try
            if ~isempty(vidObj)
                delete(vidObj);
            end

            vidObj = VideoReader(videoPath);
            frameRate = vidObj.FrameRate; % 获取帧率
            filePathLabel.Text = videoPath;
            timeSlider.Limits = [0 vidObj.Duration];
            updateDisplay(0);
            roiBtn.Enable = 'on';
            exportBtn.Enable = 'off';
            statusLabel.Text = '视频加载成功';
            delete(findobj(ax, 'Type', 'Rectangle'));
        catch ME
            errordlg(['文件加载失败: ' ME.message], '错误');
        end
    end

% 播放控制回调（修复定时器处理）
    function playControl(~,~)
        if isPlaying
            pauseVideo();
        else
            startPlayback();
        end
    end

    function startPlayback()
        if isempty(vidObj), return; end

        if vidObj.CurrentTime >= vidObj.Duration
            vidObj.CurrentTime = 0;
        end

        % 确保定时器被正确清理
        if ~isempty(timerObj) && isvalid(timerObj)
            stop(timerObj);
            delete(timerObj);
        end

        isPlaying = true;
        playBtn.Text = '暂停';

        % 创建新定时器
        timerObj = timer(...
            'ExecutionMode', 'fixedRate',...
            'Period', 1/frameRate,...
            'TimerFcn', @updateFrame);

        start(timerObj);
        statusLabel.Text = '播放中...';
    end

    function pauseVideo()
        isPlaying = false;
        playBtn.Text = '播放';
        if ~isempty(timerObj) && isvalid(timerObj)
            stop(timerObj);
            delete(timerObj);
        end
        statusLabel.Text = '已暂停';
    end

    function stopVideo(~,~)
        pauseVideo();
        vidObj.CurrentTime = 0;
        updateDisplay(0);
        timeSlider.Value = 0;
        statusLabel.Text = '已停止';
    end

% 定时器回调（添加帧率同步）
    function updateFrame(~,~)
        try
            if vidObj.CurrentTime < vidObj.Duration
                currentTime = vidObj.CurrentTime + 1/frameRate;
                vidObj.CurrentTime = currentTime;
                updateDisplay(currentTime);
                timeSlider.Value = currentTime;
                drawnow limitrate;
            else
                stopVideo();
            end
        catch ME
            handleError(ME);
        end
    end

% 进度条拖动回调
    function sliderMoved(src,~)
        if ~isPlaying
            newTime = src.Value;
            vidObj.CurrentTime = newTime;
            updateDisplay(newTime);
        end
    end

% ROI设置回调
    function setROI(~,~)
        if isempty(currentFrame)
            errordlg('请先加载视频','错误');
            return;
        end

        if ~isempty(roiPlot) && isvalid(roiPlot)
            delete(roiPlot);
        end

        title(ax, '拖动鼠标选择ROI区域 (右键结束)');
        rect = drawrectangle(ax, 'DrawingArea', [1 1 size(currentFrame,2) size(currentFrame,1)]);
        roiRect = round(rect.Position);
        delete(rect);
        title(ax, '');

        hold(ax, 'on');
        roiPlot = rectangle(ax, 'Position',roiRect,...
            'EdgeColor','r', 'LineWidth',2, 'Tag','ROI');
        hold(ax, 'off');

        exportBtn.Enable = 'on';
        statusLabel.Text = 'ROI设置完成';
    end

% 数据导出回调（修复定时器状态检查）
    function exportData(~,~)
        if isempty(vidObj) || isempty(roiRect)
            errordlg('请先选择视频和ROI','错误');
            return;
        end

        % 保存当前状态
        originalVideoTime = vidObj.CurrentTime;
        wasPlaying = isPlaying;

        % 改进的暂停逻辑
        if isPlaying
            if ~isempty(timerObj) && isvalid(timerObj)
                stop(timerObj);
                delete(timerObj);
            end
            isPlaying = false;
            playBtn.Text = '播放';
        end

        saveDir = fullfile(fileparts(videoPath), 'AnalysisResults');
        if ~exist(saveDir, 'dir')
            mkdir(saveDir);
        end

        [~,name] = fileparts(videoPath);
        timestamp = datestr(now, 'yyyymmddHHMMSS');
        savePath = fullfile(saveDir, [name '_' timestamp '_BlueData.mat']);

        hWait = waitbar(0, '正在处理视频...', 'Name','进度',...
            'CreateCancelBtn','setappdata(gcbf,''canceling'',1)');
        setappdata(hWait, 'canceling', 0);

        try
            totalFrames = floor(vidObj.Duration * frameRate);
            blueData = zeros(1, totalFrames);

            vidObj.CurrentTime = 0;
            for frameIdx = 1:totalFrames
                if getappdata(hWait, 'canceling')
                    break;
                end

                currentFrame = readFrame(vidObj);

                try
                    x1 = max(1, roiRect(1));
                    y1 = max(1, roiRect(2));
                    x2 = min(size(currentFrame,2), x1 + roiRect(3) - 1);
                    y2 = min(size(currentFrame,1), y1 + roiRect(4) - 1);
                    blueROI = currentFrame(y1:y2, x1:x2, 3);
                    blueData(frameIdx) = mean(blueROI(:));
                catch
                    blueData(frameIdx) = NaN;
                end

                waitbar(frameIdx/totalFrames, hWait,...
                    sprintf('已处理 %d/%d 帧', frameIdx, totalFrames));
            end

            save(savePath, 'blueData', 'roiRect', 'videoPath');
            vidObj.CurrentTime = originalVideoTime;

            if wasPlaying
                startPlayback();
            end

            statusLabel.Text = sprintf('数据已保存至: %s', savePath);
            msgbox(sprintf('处理完成！\n保存路径: %s', savePath), '完成');

        catch ME
            handleError(ME);
            finally
            if ishandle(hWait)
                delete(hWait);
            end
        end
    end

% 显示更新函数（添加帧号显示）
    function updateDisplay(time)
        try
            if isempty(vidObj), return; end

            vidObj.CurrentTime = time;
            currentFrame = readFrame(vidObj);

            cla(ax);
            imshow(currentFrame, 'Parent', ax);

            % 显示帧号和时间
            frameNumber = floor(time * frameRate) + 1;
            [sec, ms] = getTimeComponents(time);
            infoText = sprintf('帧: %d | 时间: %02d:%02d.%03d',...
                frameNumber, sec, floor(ms/1000), mod(ms,1000));

            infoLabel = findobj(ax.Parent, 'Tag', 'InfoLabel');
            if isempty(infoLabel)
                uilabel(ax.Parent,...
                    'Position', [10 10 300 20],...
                    'Text', infoText,...
                    'Tag', 'InfoLabel',...
                    'FontColor', 'w',...
                    'BackgroundColor', [0 0 0 0.5]);
            else
                infoLabel.Text = infoText;
            end

            if ~isempty(roiRect)
                hold(ax, 'on');
                roiPlot = rectangle(ax, 'Position',roiRect,...
                    'EdgeColor','r', 'LineWidth',2, 'Tag','ROI');
                hold(ax, 'off');
            end

        catch ME
            handleError(ME);
        end
    end

% 辅助函数
    function [sec, ms] = getTimeComponents(time)
        sec = floor(time);
        ms = round((time - sec)*1000);
    end

    function handleError(ME)
        errordlg(sprintf('发生错误:\n%s\n在文件: %s\n行号: %d',...
            ME.message, ME.stack(1).file, ME.stack(1).line), '错误');
        stopVideo();
    end

% 修改后的窗口关闭回调函数
fig.CloseRequestFcn = @closeApp;
    function closeApp(~,~)
        % 强制停止并删除定时器
        try
            if ~isempty(timerObj) && isvalid(timerObj)
                stop(timerObj);
                delete(timerObj);
            end
            timerObj = [];
        catch ME
            disp('定时器删除时发生错误:');
            disp(ME.message);
        end

        % 释放视频对象
        try
            if ~isempty(vidObj)
                delete(vidObj);
                vidObj = [];
            end
        catch ME
            disp('视频对象释放时发生错误:');
            disp(ME.message);
        end

        % 关闭等待对话框
        try
            if ~isempty(hWait) && isvalid(hWait)
                delete(hWait);
                hWait = [];
            end
        catch ME
            disp('等待对话框关闭时发生错误:');
            disp(ME.message);
        end

        % 强制删除所有图形对象
        try
            delete(fig);
        catch ME
            disp('窗口删除时发生错误:');
            disp(ME.message);
            % 最后尝试强制关闭
            close all force;
        end
    end
end
