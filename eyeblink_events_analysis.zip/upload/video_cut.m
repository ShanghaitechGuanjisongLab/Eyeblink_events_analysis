% 选择视频文件
[filename, pathname] = uigetfile('*.avi', '选择AVI视频文件');
if isequal(filename, 0)
    error('未选择文件');
end
videoPath = fullfile(pathname, filename);

% 创建VideoReader对象
v = VideoReader(videoPath);

figure;
% 读取并显示第一帧
v.CurrentTime = 0;
firstFrame = readFrame(v);
h_fig = imshow(firstFrame);
title('请依次点击左上角和右下角确认眼睛位置（请包含全部眼睛）');
hold on;  % 启用图形保持

% 初始化坐标存储
x = zeros(2,1);
y = zeros(2,1);

% 定义十字标记参数
markerSize = 2;  % 从中心向外的延伸像素数（总长度=2*markerSize+1）
lineWidth = 1;
color = 'r';

% 交互式获取两个点
for i = 1:2
    % 获取单个点
    [xi, yi] = ginput(1);
    x(i) = xi;
    y(i) = yi;
    
    % 绘制十字标记（精确到像素级）
    xi = round(xi);
    yi = round(yi);
    
    % 水平线（X方向）
    plot([xi-markerSize, xi+markerSize], [yi, yi],...
        'Color', color, 'LineWidth', lineWidth);
    % 垂直线（Y方向）
    plot([xi, xi], [yi-markerSize, yi+markerSize],...
        'Color', color, 'LineWidth', lineWidth);
    
    % 立即刷新显示
    drawnow;
end
hold off;

% 处理坐标参数
x = round(x);
y = round(y);
x_range = sort(x);
y_range = sort(y);

% 确保坐标在有效范围内
[rows, cols, ~] = size(firstFrame);
x_range = [max(1, x_range(1)), min(cols, x_range(2))];
y_range = [max(1, y_range(1)), min(rows, y_range(2))];

% 创建输出视频
[~, name, ~] = fileparts(filename);
outputVideo = VideoWriter(fullfile(pathname, [name '_cropped.avi']));
outputVideo.FrameRate = v.FrameRate;
open(outputVideo);

% 重新初始化VideoReader
v = VideoReader(videoPath);

% 进度条
h = waitbar(0, '正在处理视频...');

% 逐帧处理
while hasFrame(v)
    frame = readFrame(v);
    croppedFrame = frame(y_range(1):y_range(2), x_range(1):x_range(2), :);
    writeVideo(outputVideo, croppedFrame);
    waitbar(v.CurrentTime / v.Duration, h);
end

% 清理工作
close(outputVideo);
close(h);
disp(['处理完成！保存路径：' fullfile(pathname, [name '_cropped.avi'])]);