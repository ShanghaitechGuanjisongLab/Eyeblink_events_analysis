% 创建VideoReader对象读取输入视频
reader = VideoReader('angle00_01_cropped.avi'); % 替换为你的输入文件名

% 创建VideoWriter对象，设置帧率和文件名
writer = VideoWriter('angle00_01_cropped2.avi'); % 输出文件名
writer.FrameRate = reader.FrameRate;

% 打开VideoWriter开始写入
open(writer);

% 逐帧处理视频
while hasFrame(reader)
    % 读取当前帧
    originalFrame = readFrame(reader);
    
    % 将帧尺寸缩小到原来的1/2（面积变为1/4）
    resizedFrame = imresize(originalFrame, 0.5);
    
    % 将处理后的帧写入新视频
    writeVideo(writer, resizedFrame);
end

% 关闭VideoWriter，确保文件保存
close(writer);

disp('视频处理完成！');