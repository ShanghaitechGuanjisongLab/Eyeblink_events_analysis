% 确保输出目录存在
if ~exist('dataset3', 'dir')
    mkdir('dataset3');
end

tic;
% 获取dataset2中的所有avi文件
fileList = dir(fullfile('dataset2', '*.avi'));

% 遍历每个文件
for k = 1:length(fileList)
    % 输入文件路径
    inputFile = fullfile('dataset2', fileList(k).name);
    
    % 创建VideoReader对象
    reader = VideoReader(inputFile);
    
    % 构造输出文件名：原文件名后加3，保存在dataset3
    [~, baseName, ~] = fileparts(fileList(k).name);
    outputFile = fullfile('dataset3', [baseName, '3.avi']);
    
    % 创建VideoWriter对象
    writer = VideoWriter(outputFile);
    writer.FrameRate = reader.FrameRate;
    
    % 处理视频
    open(writer);
    while hasFrame(reader)
        originalFrame = readFrame(reader);
        resizedFrame = imresize(originalFrame, 0.5);
        writeVideo(writer, resizedFrame);
    end
    close(writer);
    
    disp(['已处理文件：', fileList(k).name]);
end
toc;
disp('所有视频处理完成！');
