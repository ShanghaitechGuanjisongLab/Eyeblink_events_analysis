%% ==================== 后处理与凸包生成（逐帧计算） ====================
% 预处理椭圆腐蚀
load(fullfile(output_folder, 'clustering_results2.mat'));  % 修改为相对路径
se = strel('square', 3);

% 初始化所有帧的凸包存储
video_check = VideoReader(video_path);
actual_frames = video_check.NumFrames;
all_frame_convex = struct('Frame', num2cell(1:actual_frames),...
                          'ConvexMask', repmat({false(video.Height, video.Width)}, 1, actual_frames));

%% 处理每个视频片段
for seg_idx = 1:num_segments
    valid_start = results(seg_idx).StartFrame;
    valid_end = min(results(seg_idx).EndFrame, actual_frames);
    
    if valid_start > actual_frames
        continue
    end
    
    current_frames = valid_start:valid_end;
    segment_length_current = length(current_frames);
    
    fprintf('\n[后处理] 处理片段 %d/%d (帧%d-%d)\n', seg_idx, num_segments, valid_start, valid_end);
    
    % 获取当前片段聚类结果
    attempts = results(seg_idx).Attempts;
    valid_masks = cell(1, try_num);
    
    %% 处理每个尝试（逐帧计算）
    for t = 1:try_num
        cluster_map = attempts{t}.ClusterIDs(1:segment_length_current,:,:);
        valid_masks_per_t = false(image_size_x, image_size_y, segment_length_current);
        
        for z = 1:segment_length_current
            frame_cluster = squeeze(cluster_map(z,:,:));
            
            % ===== 修改后的处理逻辑 =====
            current_mask_init = frame_cluster ~= 0;
            
            % 计算椭圆区域重心
            [y_coords, x_coords] = find(current_mask_init);
            if isempty(y_coords) || isempty(x_coords)
                centroid_x = 0;
                centroid_y = 0;
            else
                centroid_x = mean(x_coords);
                centroid_y = mean(y_coords);
            end
            
            % 获取所有有效聚类ID
            cluster_ids = unique(frame_cluster(current_mask_init));
            cluster_ids = cluster_ids(cluster_ids ~= 0);
            
            if isempty(cluster_ids)
                valid_masks_per_t(:,:,z) = false(size(current_mask_init));
            elseif numel(cluster_ids) == 1
                valid_masks_per_t(:,:,z) = current_mask_init;
            else
                % 计算各聚类到重心的平均距离
                avg_distances = zeros(1, numel(cluster_ids));
                for c = 1:numel(cluster_ids)
                    [y_clust, x_clust] = find(frame_cluster == cluster_ids(c));
                    distances = sqrt((x_clust - centroid_x).^2 + (y_clust - centroid_y).^2);
                    avg_distances(c) = mean(distances);
                end
                
                % 选择平均距离大的作为外侧聚类
                [~, max_idx] = max(avg_distances);
                outer_cluster = cluster_ids(max_idx);
                valid_masks_per_t(:,:,z) = (frame_cluster ~= outer_cluster) & current_mask_init;
            end
        end

        valid_masks{t} = valid_masks_per_t;
    end
    
    %% 合并尝试结果（逐帧）
    combined_mask = false(image_size_x, image_size_y, segment_length_current);
    for z = 1:segment_length_current
        mask_sum = zeros(image_size_x, image_size_y);
        for t = 1:try_num
            mask_sum = mask_sum + double(valid_masks{t}(:,:,z));
        end
        combined_mask(:,:,z) = mask_sum >= ceil(try_num/2);
    end
    
    %% 生成逐帧凸包
    for z = 1:segment_length_current
        frame_num = current_frames(z);
        mask = combined_mask(:,:,z);
        
        % ===== 原始凸包计算 =====
        [y, x] = find(mask);
        if numel(x) > 2
            k = convhull(x, y);
            convex_mask = poly2mask(x(k), y(k), image_size_x, image_size_y);
        else
            convex_mask = false(image_size_x, image_size_y);
        end
        all_frame_convex(frame_num).ConvexMask = convex_mask;
    end
end

%% ===== 最终结果保存 =====
save(fullfile(output_folder, 'final_convex_results.mat'), 'all_frame_convex', '-v7.3');
fprintf('\n后处理完成！结果已保存至：%s\n', fullfile(output_folder, 'final_convex_results.mat'));

%% 生成最终视频
output_video = VideoWriter('final_video_with_convex.avi');
open(output_video);
video_refresh = VideoReader(video_path);

frame_try = -1;
for frame_num = 1:actual_frames
    img = read(video_refresh, frame_num);
    convex_mask = all_frame_convex(frame_num).ConvexMask;
    
    % 叠加凸包边界
    boundary = bwperim(convex_mask);
    img = double(img)/255;
    img(:,:,1) = min(img(:,:,1) + 0.8*double(boundary), 1);
    img(:,:,2) = min(img(:,:,2) + 0.8*double(boundary), 1);
    img(:,:,3) = max(img(:,:,3) - 0.8*double(boundary), 0);
    img = uint8(img*255);
    
    writeVideo(output_video, img);
    frame_k = round(frame_num/actual_frames*100);
    if frame_k > frame_try
        frame_try = frame_k;
        fprintf('处理进度: %3d%%\r', frame_k);
    end
end
close(output_video);
fprintf('\n视频生成完成！\n');