clc; clear; close all;
addpath(genpath(pwd));

%% 参数设置
output_folder = './cluster_results_base';
mkdir(output_folder);

%% 获取所有AVI文件路径
avi_files = dir(fullfile('dataset3', '**', '*.avi')); % 递归获取子文件夹中的AVI

%% 遍历处理每个视频
for fidx = 1:length(avi_files)
    video_path = fullfile(avi_files(fidx).folder, avi_files(fidx).name);
    [~, video_name, ~] = fileparts(video_path); % 提取纯文件名
    
    %% 视频读取配置
    video = VideoReader(video_path);
    total_frames = video.NumFrames;
    [image_size_x, image_size_y] = deal(video.Height, video.Width);
    
    %% 超参数配置
    layer_num = 2;
    unit_iter = 200;
    sub_iter = 200;
    try_num = 9;
    MaxIter = 500;
    
    final_n = [4];
    z_weight = 1;  % 固定为1（因为每个片段都是25帧）
    segment_length = 25;
    % 计算n_list
    frame_unit_num = segment_length * image_size_x * image_size_y;
    v1 = (frame_unit_num / final_n)^(1/5);
    n_list = [];
    n2 = final_n;
    for k = 1:layer_num
        n_list = [n2, n_list];
        n2 = n2 * v1;
    end
    
    
    %% 计算视频片段
    segment_overlap = 12;
    
    start_frames = 1:(segment_length-segment_overlap):(total_frames-segment_length+1);
    num_segments = length(start_frames);
    
    %% 初始化结果存储结构体
    results = struct(...
        'SegmentNumber', {}, ...
        'StartFrame', {}, ...
        'EndFrame', {}, ...
        'Attempts', {});
    
    fprintf('总视频片段数: %d\n', num_segments);
    
    %% 主处理循环
    tic;
    for seg_idx = 1:num_segments
        current_start = start_frames(seg_idx);
        current_end = current_start + segment_length - 1;
        
        fprintf('\n正在处理片段 %d/%d (帧%d-%d)\n', seg_idx, num_segments, current_start, current_end);
        if seg_idx == 2
            toc;
            break;
        end
        %% 读取当前片段
        data_raw = zeros(segment_length, image_size_x, image_size_y, 3);
        for i = 1:segment_length
            data_raw(i, :, :, :) = im2double(read(video, current_start + i - 1));
        end
        
        %% 构建特征矩阵
        unit_list_all = [];
        for z = 1:segment_length
            frame_data = squeeze(data_raw(z, :, :, :));
            for k = 1:image_size_x
                for r = 1:image_size_y
                    unit1 = [k r z*z_weight reshape(frame_data(k, r, :)*255, [1,3])];
                    unit_list_all = [unit_list_all; unit1];
                end
            end
        end
        unit_list_all(:,6) = 0*unit_list_all(:,6);
        
        %% 聚类处理
        all_attempts = cell(1, try_num);
        for t = 1:try_num
            switch t
                case 1
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [16 4];
                case 2
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [16 3];
                case 3
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [16 2];
                case 4
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [8 3];
                case 5
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [8 2];
                case 6
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [16 8];
                case 7
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [32 8];
                case 8
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [32 4];
                case 9
                    size_weight_list = [8 2];
                    unit_kernel_num_list = [8 4];
            end
            fprintf('  尝试 %d/%d...', t, try_num);
            temp_all = zeros(segment_length, image_size_x, image_size_y, 3);
            unit_data_a = unit_list_all;
            unit_data_a(:, 1:3) = unit_data_a(:, 1:3)/((image_size_x+image_size_y)/2)*32;
            
            for s = 1:layer_num
                unit_kernel_num = unit_kernel_num_list(s);
                unit_data_a(:, 1:3) = unit_data_a(:, 1:3) * size_weight_list(s);
                
                min_error = inf;
                for k = 1:round(unit_iter/sub_iter)
                    error_list = zeros(1, sub_iter);
                    idx_list = cell(1, sub_iter);
                    unit_center_list = cell(1, sub_iter);
                    recons_unit1_list = cell(1, sub_iter);
                    
                    parfor r = 1:sub_iter
                        [idx_k, unit_cluster_center_k, ~, recons_unit1_k] = ...
                            kmeansWithError(unit_data_a, unit_kernel_num, MaxIter);
                        error_list(r) = sum(sum((unit_data_a - recons_unit1_k).^2));
                        idx_list{r} = idx_k;
                        unit_center_list{r} = unit_cluster_center_k;
                        recons_unit1_list{r} = recons_unit1_k;
                    end
                    
                    [min_error_r, no1] = min(error_list);
                    if min_error_r < min_error
                        min_error = min_error_r;
                        idxa = idx_list{no1};
                        unit_center = unit_center_list{no1};
                        recons_unit = recons_unit1_list{no1};
                    end
                end
                
                color_lista = round(unit_center(:, 4:6));
                for k = 1:size(unit_list_all,1)
                    z = round(unit_list_all(k, 3)/z_weight);
                    temp_all(z, unit_list_all(k,1), unit_list_all(k,2), :) = color_lista(idxa(k),:)/255;
                end
                unit_data_a(:, 1:3) = recons_unit(:, 1:3)/size_weight_list(s);
            end
            all_attempts{t} = temp_all;
            fprintf('完成\n');
        end
        
        %% 保存到结构体
        results(seg_idx).SegmentNumber = seg_idx;
        results(seg_idx).StartFrame = current_start;
        results(seg_idx).EndFrame = current_end;
        results(seg_idx).Attempts = all_attempts;
    end
    
    
    %% ========== 修改后的可视化及交互部分 ==========
    % 只处理第一个片段
    target_segment = 1;
    all_attempts = results(target_segment).Attempts;
    try_num = numel(all_attempts);
    
    % 读取原始视频对应帧
    video = VideoReader(video_path); % 重新初始化视频对象
    original_frame = im2double(read(video, start_frames(target_segment))); % 读取第一帧原始图像
    
    % 创建可视化画布
    figure('Name','聚类结果与原始帧对比','Position',[100 100 1600 900]);
    
    % 添加整体提示
    sgtitle('聚类结果对比（左侧原始帧，右侧各尝试结果）', 'FontSize', 14, 'Color', 'b');
    annotation('textbox', [0.1 0.95 0.8 0.05], 'String',...
        '请在命令行中输入最像眼睛的编号（显示在子图下方）',...
        'EdgeColor','none','HorizontalAlignment','center','FontSize',12,'Color','r');
    
    % 计算子图布局（原始帧 + 所有尝试）
    total_plots = try_num + 1;
    subplot_rows = ceil(sqrt(total_plots));
    subplot_cols = ceil(total_plots / subplot_rows);
    
    % 显示原始视频帧
    subplot(subplot_rows, subplot_cols, 1);
    imshow(original_frame);
    title('原始视频帧', 'FontSize', 10);
    axis equal tight;
    set(gca,'XTick',[], 'YTick',[]);
    text(0.5, -0.1, '参考帧',...
        'Units','normalized','HorizontalAlignment','center',...
        'FontSize',10,'Color','k','FontWeight','bold');
    
    % 绘制所有尝试的第一帧
    for t = 1:try_num
        subplot_pos = t + 1; % 第一个位置已用于原始帧
        subplot(subplot_rows, subplot_cols, subplot_pos);
        
        % 从results提取数据
        temp_all = all_attempts{t};
        cluster_frame = squeeze(temp_all(1,:,:,:)); % 提取完整RGB帧
        
        imshow(cluster_frame);
        title(sprintf('尝试 %d', t), 'FontSize', 10);
        axis equal tight;
        set(gca,'XTick',[], 'YTick',[]);
        
        % 在图像下方添加编号标识
        text(0.5, -0.1, sprintf('编号: %d', t),...
            'Units','normalized','HorizontalAlignment','center',...
            'FontSize',10,'Color','k','FontWeight','bold');
    end
    
    %% 用户交互选择部分
    % 获取有效输入
    valid = false;
    while ~valid
        user_input = input('请输入您选择的编号（显示在子图下方）: ', 's');
        selected_idx = str2double(user_input);
        
        if ~isnan(selected_idx) && selected_idx >= 1 &&...
           selected_idx <= try_num && rem(selected_idx,1) == 0
            valid = true;
        else
            fprintf('! 输入无效，请输入1-%d之间的整数 !\n', try_num);
        end
    end
    
    %% 保存选中结果
    % 更新所有片段的Attempts
    for seg_idx = 1:numel(results)
        original_attempts = results(seg_idx).Attempts;
        results(seg_idx).Attempts = original_attempts(selected_idx);
    end
        %% 保存结果（包含视频名称）
    selected_file = fullfile(output_folder,...
        sprintf('clustering_results_base_%s.mat', video_name)); % 添加视频名称标识
    
    save(selected_file, 'results', '-v7.3');
    fprintf('\n已保存选择结果至: %s\n', selected_file);
end % 结束视频遍历循环