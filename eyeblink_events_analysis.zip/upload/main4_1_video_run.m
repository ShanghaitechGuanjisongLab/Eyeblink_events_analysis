clc; clear; close all;
addpath(genpath(pwd));

%% 参数设置
output_folder = './cluster_results';
mkdir(output_folder);
video_dir = './dataset3';
video_files = dir(fullfile(video_dir, '*.avi'));

%% 创建视频校验目录
check_video_dir = './check_video';
mkdir(check_video_dir);

%% 批量处理所有视频
total_time = tic;

for vid_idx = 1:length(video_files)
    tic;
    current_video = video_files(vid_idx).name;
    [~, base_name, ~] = fileparts(current_video);
    
    %% 动态生成路径
    video_path = fullfile(video_dir, current_video);
    mat_file = fullfile('./cluster_results_base', ['clustering_results_base_' base_name '.mat']);
    
    if ~exist(mat_file, 'file')
        fprintf('跳过视频 %s: .mat文件不存在\n', current_video);
        continue;
    end
    
    %% 主处理逻辑
    binary_image = visualize_best_ellipse(mat_file);
    video = VideoReader(video_path);
    
    total_frames = video.NumFrames;
    [image_size_x, image_size_y] = deal(video.Height, video.Width);
    
    %% 超参数配置
    layer_num = 2;
    unit_iter = 20;
    sub_iter = 20;
    try_num = 5;
    MaxIter = 500;
    size_weight_list = [8 2];
    final_n = [4];
    z_weight = 1;
    
    frame_unit_num = 25 * image_size_x * image_size_y;
    v1 = (frame_unit_num / final_n)^(1/5);
    n_list = [];
    n2 = final_n;
    for k = 1:layer_num
        n_list = [n2, n_list];
        n2 = n2 * v1;
    end
    unit_kernel_num_list = [8 2];
    
    %% 计算视频片段
    segment_overlap = 0;
    segment_length = 25;
    start_frames = 1:(segment_length-segment_overlap):(total_frames-segment_length+1);
    num_segments = length(start_frames);
    
    %% 初始化存储结构
    results = struct('SegmentNumber', {}, 'StartFrame', {}, 'EndFrame', {}, 'Attempts', {});
    
    binary_image = double(binary_image);
    base_image = binary_image;
    base_edge = 1;
    for k = -base_edge:base_edge
        for r = -base_edge:base_edge
            base_image(base_edge+1+k:end-base_edge+k,base_edge+1+r:end-base_edge+r) = ...
                base_image(base_edge+1+k:end-base_edge+k,base_edge+1+r:end-base_edge+r) + ...
                binary_image(base_edge+1:end-base_edge,base_edge+1:end-base_edge);
        end
    end
    
    %% 主处理循环
    fprintf('总视频片段数: %d\n', num_segments);
    tic;
    for seg_idx = 1:num_segments
        current_start = start_frames(seg_idx);
        current_end = current_start + segment_length - 1;
        
        fprintf('\n[进度] 处理片段 %d/%d (帧%d-%d)\n', seg_idx, num_segments, current_start, current_end);
        
        %% 读取当前片段
        data_raw = zeros(segment_length, image_size_x, image_size_y, 3);
        for i = 1:segment_length
            data_raw(i, :, :, :) = im2double(read(video, current_start + i - 1));
        end
    
        %% 构建特征矩阵
        unit_list_all = [];
        for z = 1:segment_length
            frame_data = squeeze(data_raw(z, :, :, :));
            for k = 1:image_size_x
                for r = 1:image_size_y
                    if base_image(k,r) > 0.5
                        unit1 = [k r z*z_weight reshape(frame_data(k, r, :)*255, [1,3])];
                        unit_list_all = [unit_list_all; unit1];
                    end
                end
            end
        end
        unit_list_all(:,6) = 0*unit_list_all(:,6);
        
        %% 聚类处理
        all_attempts = cell(1, try_num);
        for t = 1:try_num
            fprintf('  尝试 %d/%d...', t, try_num);
            
            temp_all = zeros(segment_length, image_size_x, image_size_y, 3);
            cluster_ids_all = zeros(size(unit_list_all,1), layer_num);
            unit_data_a = unit_list_all;
            unit_data_a(:, 1:3) = unit_data_a(:, 1:3)/25*32;
            
            for s = 1:layer_num
                unit_kernel_num = unit_kernel_num_list(s);
                unit_data_a(:, 1:3) = unit_data_a(:, 1:3) * size_weight_list(s);
                
                min_error = inf;
                for k = 1:round(unit_iter/sub_iter)
                    parfor r = 1:sub_iter
                        [idx_k, unit_cluster_center_k, ~, recons_unit1_k] = ...
                            kmeansWithError(unit_data_a, unit_kernel_num, MaxIter);
                        error_list(r) = sum(sum((unit_data_a - recons_unit1_k).^2));
                        idx_list{r} = idx_k;
                        unit_center_list{r} = unit_cluster_center_k;
                        recons_unit1_list{r} = recons_unit1_k;
                    end
                    
                    [min_error_r, no1] = min(error_list);
                    if min_error_r < min_error
                        min_error = min_error_r;
                        idxa = idx_list{no1};
                        unit_center = unit_center_list{no1};
                        recons_unit = recons_unit1_list{no1};
                    end
                end
                
                cluster_ids_all(:, s) = idxa;
                color_lista = round(unit_center(:, 4:6));
                for k = 1:size(unit_list_all,1)
                    z = round(unit_list_all(k, 3)/z_weight);
                    temp_all(z, unit_list_all(k,1), unit_list_all(k,2), :) = color_lista(idxa(k),:)/255;
                end
                unit_data_a(:, 1:3) = recons_unit(:, 1:3)/size_weight_list(s);
            end
            
            final_cluster_map = zeros(segment_length, image_size_x, image_size_y, 'uint16');
            ptr = 1;
            for z = 1:segment_length
                for x = 1:image_size_x
                    for y = 1:image_size_y
                        if base_image(x,y) > 0.5
                            final_cluster_map(z,x,y) = cluster_ids_all(ptr, end);
                            ptr = ptr + 1;
                        end
                    end
                end
            end
            
            all_attempts{t} = struct('Reconstructed', temp_all, 'ClusterIDs', final_cluster_map);
            fprintf('完成 (耗时%.1fs)\n', toc);
        end
        
        %% 保存结果
        results(seg_idx).SegmentNumber = seg_idx;
        results(seg_idx).StartFrame = current_start;
        results(seg_idx).EndFrame = current_end;
        results(seg_idx).Attempts = all_attempts;
    end

    %% 保存结果
    save_name = sprintf('clustering_results2_%s.mat', base_name);
    save_path = fullfile(output_folder, save_name);
    save(save_path, 'results', '-v7.3');
    
    fprintf('视频 %d/%d 处理完成，耗时 %.1f秒\n', vid_idx, length(video_files), toc);

    se = strel('square', 3);

    % 初始化所有帧的凸包存储
    video_check = VideoReader(video_path);
    actual_frames = video_check.NumFrames;
    all_frame_convex = struct('Frame', num2cell(1:actual_frames),...
                              'ConvexMask', repmat({false(video.Height, video.Width)}, 1, actual_frames));
    
    %% 处理每个视频片段
    for seg_idx = 1:num_segments
        valid_start = results(seg_idx).StartFrame;
        valid_end = min(results(seg_idx).EndFrame, actual_frames);
        
        if valid_start > actual_frames
            continue
        end
        
        current_frames = valid_start:valid_end;
        segment_length_current = length(current_frames);
        
        fprintf('\n[后处理] 处理片段 %d/%d (帧%d-%d)\n', seg_idx, num_segments, valid_start, valid_end);
        
        attempts = results(seg_idx).Attempts;
        valid_masks = cell(1, try_num);
        
        %% 处理每个尝试
        for t = 1:try_num
            cluster_map = attempts{t}.ClusterIDs(1:segment_length_current,:,:);
            valid_masks_per_t = false(image_size_x, image_size_y, segment_length_current);
            
            for z = 1:segment_length_current
                frame_cluster = squeeze(cluster_map(z,:,:));
                current_mask_init = frame_cluster ~= 0;
                
                [y_coords, x_coords] = find(current_mask_init);
                if isempty(y_coords)
                    centroid_x = 0;
                    centroid_y = 0;
                else
                    centroid_x = mean(x_coords);
                    centroid_y = mean(y_coords);
                end
                
                cluster_ids = unique(frame_cluster(current_mask_init));
                cluster_ids = cluster_ids(cluster_ids ~= 0);
                
                if isempty(cluster_ids)
                    valid_masks_per_t(:,:,z) = false(size(current_mask_init));
                elseif numel(cluster_ids) == 1
                    valid_masks_per_t(:,:,z) = current_mask_init;
                else
                    avg_distances = zeros(1, numel(cluster_ids));
                    for c = 1:numel(cluster_ids)
                        [y_clust, x_clust] = find(frame_cluster == cluster_ids(c));
                        distances = sqrt((x_clust - centroid_x).^2 + (y_clust - centroid_y).^2);
                        avg_distances(c) = mean(distances);
                    end
                    
                    [~, max_idx] = max(avg_distances);
                    outer_cluster = cluster_ids(max_idx);
                    valid_masks_per_t(:,:,z) = (frame_cluster ~= outer_cluster) & current_mask_init;
                end
            end
    
            valid_masks{t} = valid_masks_per_t;
        end
        
        %% 合并尝试结果
        combined_mask = false(image_size_x, image_size_y, segment_length_current);
        for z = 1:segment_length_current
            mask_sum = zeros(image_size_x, image_size_y);
            for t = 1:try_num
                mask_sum = mask_sum + double(valid_masks{t}(:,:,z));
            end
            combined_mask(:,:,z) = mask_sum >= ceil(try_num/2);
        end
        
        %% 生成逐帧凸包（修复部分）
        for z = 1:segment_length_current
            frame_num = current_frames(z);
            mask = combined_mask(:,:,z);
            
            [y, x] = find(mask);
            convex_mask = false(image_size_x, image_size_y);
            
            if numel(x) >= 2
                try
                    % 正常计算凸包
                    k = convhull(x, y);
                    convex_mask = poly2mask(x(k), y(k), image_size_x, image_size_y);
                catch
                    % 处理共线情况
                    if numel(x) >= 2
                        % 创建最小包围矩形
                        x_min = max(1, min(x)-1);
                        x_max = min(image_size_y, max(x)+1);
                        y_min = max(1, min(y)-1);
                        y_max = min(image_size_x, max(y)+1);
                        
                        convex_mask(y_min:y_max, x_min:x_max) = true;
                    end
                end
            end
            all_frame_convex(frame_num).ConvexMask = convex_mask;
        end
    end
    
    eye_data = zeros(1,numel(all_frame_convex));
    for k = 1:numel(all_frame_convex)
        d1 = all_frame_convex(k).ConvexMask;
        d1 = sum(sum(double(d1)));
        eye_data(k) = d1;
    end

    %% 保存后处理结果
    convex_save_name = sprintf('final_convex_results_%s.mat', base_name);
    convex_save_path = fullfile(output_folder, convex_save_name);
    save(convex_save_path, 'all_frame_convex', 'eye_data', '-v7.3');
    
    %% 生成校验视频
    check_video_name = sprintf('final_video_with_convex_%s.avi', base_name);
    check_video_path = fullfile(check_video_dir, check_video_name);
    
    output_video = VideoWriter(check_video_path);
    open(output_video);
    video_refresh = VideoReader(video_path);
    
    frame_try = -1;
    for frame_num = 1:actual_frames
        img = read(video_refresh, frame_num);
        convex_mask = all_frame_convex(frame_num).ConvexMask;
        
        boundary = bwperim(convex_mask);
        img = double(img)/255;
        img(:,:,1) = min(img(:,:,1) + 0.8*double(boundary), 1);
        img(:,:,2) = min(img(:,:,2) + 0.8*double(boundary), 1);
        img(:,:,3) = max(img(:,:,3) - 0.8*double(boundary), 0);
        img = uint8(img*255);
        
        writeVideo(output_video, img);
        frame_k = round(frame_num/actual_frames*100);
        if frame_k > frame_try
            frame_try = frame_k;
            fprintf('处理进度: %3d%%\r', frame_k);
        end
    end
    close(output_video);
    fprintf('\n视频生成完成！\n');
end

%% 最终输出
fprintf('\n全部处理完成！总耗时 %.1f秒\n', toc(total_time));
