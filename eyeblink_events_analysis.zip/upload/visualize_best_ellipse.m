function binary_image = visualize_best_ellipse(data_path)
arguments
    data_path = './cluster_results_base/clustering_results_base_mouse1_cropped3.mat'
end
    % 加载数据
    load(data_path, 'results');
    segment1_attempts = results(1).Attempts;
    
    % 创建画布
    figure('Position', [100, 100, 1600, 800]);
    sgtitle('第一个视频片段的n1次尝试 - 最佳椭圆聚类块检测');
    
    n1 = numel(results.Attempts);
    % 初始化存储椭圆参数的容器
    ellipse_params = cell(1, n1);
    all_masks = cell(1, n1);
    
    % 遍历n1次尝试
    for t = 1:n1
        % ========== 数据准备 ==========
        frame_data = squeeze(segment1_attempts{t}(1, :, :, :));
        [height, width, ~] = size(frame_data);
        
        % ========== 聚类块解析 ==========
        [unique_colors, ~, color_labels] = unique(reshape(frame_data, [], 3), 'rows');
        color_labels = reshape(color_labels, height, width);
        
        % ========== 椭圆检测 ==========
        best_score = -inf;
        best_mask = false(height, width);
        current_params = struct();
        
        % 遍历每个颜色聚类块
        for k = 1:size(unique_colors, 1)
            cluster_mask = (color_labels == k);
            if nnz(cluster_mask) < 20
                continue;
            end
            
            [current_mask, current_score, params] = evaluate_ellipse(cluster_mask);
            
            if current_score > best_score
                best_score = current_score;
                best_mask = current_mask;
                current_params = params;
            end
        end
        
        % 存储椭圆参数和掩膜
        all_masks{t} = best_mask;
        if ~isempty(current_params.Centroid)
            ellipse_params{t} = current_params;
        end
        
        % ========== 可视化 ==========
        % 原始聚类图像
        subplot(3, n1, t);
        imshow(frame_data);
        title(sprintf('尝试 %d - 原始聚类', t));
        
        % 椭圆区域叠加显示
        subplot(3, n1, t+n1);
        imshow(frame_data);
        hold on;
        if best_score > 0
            contourf = bwboundaries(best_mask);
            for b = 1:length(contourf)
                plot(contourf{b}(:, 2), contourf{b}(:, 1), 'r', 'LineWidth', 2);
            end
        end
        hold off;
        title(sprintf('椭圆得分: %.2f', best_score));
        
        % 黑白二值图
        subplot(3, n1, t+2*n1);
        binary_img = ones(height, width);
        binary_img(best_mask) = 0;
        imshow(binary_img);
        title('椭圆区域二值化');
    end

    % ========== 找到最接近平均值的椭圆 ==========
    % 提取有效椭圆参数
    valid_params = ellipse_params(~cellfun(@isempty, ellipse_params));
    if isempty(valid_params)
        binary_image = [];
        return;
    end
    
    % 计算参数平均值
    centroids = cellfun(@(x) x.Centroid, valid_params, 'UniformOutput', false);
    centroids = vertcat(centroids{:});
    mean_centroid = mean(centroids, 1);
    
    axes_lengths = cellfun(@(x) [x.MajorAxisLength, x.MinorAxisLength], valid_params, 'UniformOutput', false);
    axes_lengths = vertcat(axes_lengths{:});
    mean_axes = mean(axes_lengths, 1);
    
    % 计算每个椭圆与平均值的差异
    distances = zeros(1, length(valid_params));
    for i = 1:length(valid_params)
        % 位置差异（归一化）
        pos_diff = norm(valid_params{i}.Centroid - mean_centroid) / norm([width, height]);
        
        % 尺寸差异（归一化）
        size_diff = norm([valid_params{i}.MajorAxisLength, valid_params{i}.MinorAxisLength] - mean_axes) / norm(mean_axes);
        
        % 综合距离
        distances(i) = pos_diff + size_diff;
    end
    
    % 选择最接近平均值的椭圆
    [~, best_idx] = min(distances);
    binary_image = all_masks{best_idx};

    % ========== 高亮显示最终选择的椭圆 ==========
    for t = 1:n1
        % 在原有可视化基础上添加最终选择标记
        if t == best_idx
            % 原始聚类图像
            subplot(3, n1, t);
            hold on;
            rectangle('Position', [mean_centroid(1)-10, mean_centroid(2)-10, 20, 20],...
                     'EdgeColor', 'g', 'LineWidth', 2, 'Curvature', 1);
            hold off;
        end
    end
end

function [best_mask, best_score, params] = evaluate_ellipse(mask)
    % 初始化输出
    best_mask = false(size(mask));
    best_score = 0;
    params = struct('Centroid', [], 'MajorAxisLength', [], 'MinorAxisLength', []);
    
    % 连通区域分析
    labeled_mask = bwlabel(mask);
    stats = regionprops(labeled_mask, ...
        'Area', 'Eccentricity', 'Solidity', 'MajorAxisLength', 'MinorAxisLength', 'Centroid');
    
    % 过滤无效区域
    valid_idx = find([stats.Area] >= 20 & ...          % 最小面积
                    [stats.Eccentricity] < 0.95 & ...   % 排除过于细长
                    [stats.Solidity] > 0.8);            % 排除多孔区域
    
    if isempty(valid_idx)
        return;
    end
    
    % 计算椭圆匹配度评分
    scores = zeros(1, length(valid_idx));
    for i = 1:length(valid_idx)
        idx = valid_idx(i);
        area_weight = log10(stats(idx).Area);
        eccentricity_score = 1 - abs(0.7 - stats(idx).Eccentricity);
        aspect_score = 1 - abs(1 - stats(idx).MajorAxisLength/stats(idx).MinorAxisLength)/2;
        
        scores(i) = area_weight * eccentricity_score * aspect_score;
    end
    
    % 选择最佳区域
    [best_score, best_idx] = max(scores);
    best_region = valid_idx(best_idx);
    best_mask = (labeled_mask == best_region);
    
    % 提取椭圆参数
    params.Centroid = stats(best_region).Centroid;
    params.MajorAxisLength = stats(best_region).MajorAxisLength;
    params.MinorAxisLength = stats(best_region).MinorAxisLength;
end
