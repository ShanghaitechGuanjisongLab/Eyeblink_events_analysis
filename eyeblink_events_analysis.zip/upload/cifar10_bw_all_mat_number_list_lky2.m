clc;
clear;
close all;
addpath(genpath(pwd)); % Call the functions in all folders in the current folder
data_path = './dataset/data_batch_1.mat';
load(data_path);
tic;
%% 超参数设置
image_size_x = size(data, 1); % 图像尺寸
image_size_y = size(data, 2); % 图像尺寸
image_channels = 3; % 图像通道数
label_idx = 0;

layer_num = 6;

unit_iter = 2000; % 迭代次数，尝试不同的聚类中心数目
sub_iter = 2000;
try_num = 30; % 总尝试轮数

error_allow = 12;
%% 预处理
% 初始化
custom_format_time = datestr(now, 'yyyy-mm-dd HH:MM:SS');
disp(custom_format_time);
%% Preprocess
% Init
image_size_x = 32;
image_size_y = 32;
batch = 200;
data_raw = zeros(batch, image_size_x, image_size_y, image_channels);
label_raw = [];
count = 0;
% Traverse labels and select 20 images with labels of 0或8
for i = 1:numel(labels)
    if labels(i) == label_idx
        count = count + 1;
        temp = reshape(data(i,:), [image_size_x, image_size_y, image_channels]);
        for channel = 1:image_channels
            temp(:, :, channel) = temp(:, :, channel)';
        end
        data_raw(count, :, :, :) = temp;
        label_raw = [label_raw; labels(i)];
    end
    if count == batch
        break;
    end
end
%% K-means聚类分析
tic;
for image_idx = 1:100 % 特定图像索引
    fprintf(['image_ID:' num2str(image_idx) '\n']);
    data1 = data_raw(image_idx, :, :, :);
    data1 = reshape(data1, [image_size_x, image_size_y, image_channels]);
    unit_list = zeros(image_size_x, image_size_y, 5);
    % 将每个像素点转换为特征向量，包含位置信息和颜色信息
    for k = 1:image_size_x
        for r = 1:image_size_y
            unit1 = [k r reshape(data1(k,r,:),[1, image_channels])];
            unit_list(k,r,:) = unit1;
        end
    end
    unit_list = reshape(unit_list, [image_size_x*image_size_y, 5]);
    
    % 存储所有生成的黑白图像
    bw_images_all = [];
    tic;
    for t = 1:try_num
        t1 = mod(t,5);
        switch t1
            case 0
                size_weight_list = [128 64 32 16 8 4];
            case 1
                size_weight_list = [112 50 22.5 10 4.5 2];
            case 2
                size_weight_list = [100 40 16 6.3 2.5 1];
            case 3
                size_weight_list = [87 31 11 3.92 1.4 .5];
            case 4
                size_weight_list = [85 26.5 8.3 2.6 .8 .25];
        end
        unit_kernel_num_list = round([436 168 70 32 16 11]*1);
        color_kernel_num_limit = unit_kernel_num_list(end);
        unit_data_a = unit_list;
        fprintf(num2str(t));
        for s = 1:layer_num
            % 初始化聚类结果存储结构
            unit_kernel_num = unit_kernel_num_list(s);
            unit_data_a(:,1:2) = unit_data_a(:,1:2)*size_weight_list(s);
            min_error = inf;
            idxa = [];
            unit_center = [];
            % 并行计算，执行K-means聚类
            for k = 1:round(unit_iter/sub_iter)
                error_list = zeros(1,sub_iter);
                idx_list = cell(1,sub_iter);
                unit_center_list = cell(1,sub_iter);
                recons_unit_list = cell(1,sub_iter);
                parfor r = 1:sub_iter
                    [idx_k, unit_cluster_center_k, unit_cluster_error_k, recons_unit1_k] = kmeansWithError(unit_data_a, unit_kernel_num);
                    error_list(r) = unit_cluster_error_k;
                    idx_list{r} = idx_k;
                    unit_center_list{r} = unit_cluster_center_k;
                    recons_unit_list{r} = recons_unit1_k;
                end
                % 选择最小误差的聚类结果
                [min_error_r, no1] = min(error_list);
                if min_error_r < min_error
                    min_error = min_error_r;
                    idxa = idx_list{no1};
                    unit_center = unit_center_list{no1};
                    recons_unit = recons_unit_list{no1};
                end
            end
            color_lista = round(unit_center(:,3:5));
            fprintf('-');
            % 可视化聚类结果
            temp = zeros([image_size_x, image_size_y, image_channels]);
            for k = 1:size(unit_data_a, 1)
                unit1 = unit_list(k,:);
                idx1 = idxa(k);
                temp(round(unit1(1)), round(unit1(2)), :) = color_lista(idx1, :); % 根据聚类索引着色
            end
            unit_data_a = recons_unit;
            unit_data_a(:,1:2) = recons_unit(:,1:2)/size_weight_list(s);
        end
        if t == 1 || mod(t,10) == 0
            toc;
        end
        
        bw_images = temp;
        bw_images_all = cat(4, bw_images_all, bw_images);
    end
    
    dist1 = sum(sum(sum((temp - data1).^2)))/numel(temp);
    fprintf(['dist = ' num2str(dist1^(1/2)) '\n']);
    figure;
    imshow(uint8(data1), 'border', 'tight', 'initialmagnification', 'fit');
    
    % 保存所有黑白图像到.mat文件，文件名包含图像索引
    % save(['.\bw_images_all_image_airplane2\bw_images_all_image_' num2str(image_idx) '.mat'], 'bw_images_all','-v7.3');
    save(['.\bw_images_all_image_airplane3\bw_images_all_image_' num2str(image_idx) '.mat'], 'bw_images_all');
end

