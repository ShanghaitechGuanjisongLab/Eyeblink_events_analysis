%% 增强版数据保存（支持重命名）
% 选择保存路径
savePath = uigetdir('请选择保存文件夹');
if savePath == 0
    disp('用户取消保存操作');
    return;
end

% 文件名输入对话框
nameValid = false;
while ~nameValid
    defaultName = ['EyeData_' datestr(now, 'yyyy-mm-dd')];
    newName = inputdlg('请输入文件名（不要包含特殊字符）:',...
                      '保存数据',...
                      [1 50],...
                      {defaultName});
    
    % 用户取消输入
    if isempty(newName)
        disp('用户取消重命名');
        newName = defaultName;
        nameValid = true;
        break;
    end
    
    % 验证文件名
    cleanName = matlab.lang.makeValidName(newName{1}); % 自动清理非法字符
    if ~strcmp(cleanName, newName{1})
        msg = {'包含非法字符已自动修正：', ['原名称：' newName{1}], ['新名称：' cleanName]};
        uialert(gcf, msg, '名称修正', 'Icon','warning');
    end
    
    % 检查是否已存在文件
    tempPath = fullfile(savePath, [cleanName '.mat']);
    if exist(tempPath, 'file')
        answer = questdlg('文件已存在，是否覆盖？', '冲突警告',...
                         '覆盖', '重新命名', '取消', '取消');
        switch answer
            case '覆盖'
                nameValid = true;
            case '重新命名'
                continue;
            otherwise
                disp('保存操作已取消');
                return;
        end
    else
        nameValid = true;
    end
    newName = cleanName;
end

% 生成最终文件名（带时间戳）
finalName = [newName '_' datestr(now, 'mmddHHMMSS')];
fullMatPath = fullfile(savePath, [finalName '.mat']);
fullCsvPath = fullfile(savePath, [finalName '.csv']);

% 保存数据
save(fullMatPath, 'outputData');
disp(['MAT文件已保存至: ' fullMatPath]);

% 保存CSV文件
% try
%     fid = fopen(fullCsvPath, 'w');
%     fprintf(fid, 'Cell Number,Time Points (s)\n');
%     for k = 1:numCells
%         fprintf(fid, '%d,"%s"\n', k, strjoin(cellstr(num2str(outputData{k}, '%.3f')), ', '));
%     end
%     fclose(fid);
%     disp(['CSV文件已保存至: ' fullCsvPath]);
% catch ME
%     warning('CSV保存失败: %s', ME.message);
% end

% 完成提示
msgbox({'数据保存完成：',...
       ['MAT文件: ' finalName '.mat']},...
       '保存成功');
