function [idx, clusters, error, reconstruct_data] = kmeansWithError(data, k, MaxIter)
arguments
    data 
    k 
    MaxIter = 200
end
    [idx, clusters] = kmeans(data, k, 'MaxIter', MaxIter);
    % error = 0;
    reconstruct_data = zeros(size(data));
    for i = 1:size(data, 1)
        % error = error + norm(data(i, :) - clusters(idx(i), :));
        reconstruct_data(i, :) = clusters(idx(i), :);
    end
    error = sum(sqrt(sum((data - reconstruct_data).^2,2)));
end
