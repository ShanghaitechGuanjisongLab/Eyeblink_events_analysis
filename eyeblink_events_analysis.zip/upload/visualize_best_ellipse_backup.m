function binary_image = visualize_best_ellipse()
    % 加载数据
    load('./cluster_results/clustering_results.mat', 'results');
    segment1_attempts = results(1).Attempts;
    
    % 创建画布
    figure('Position', [100, 100, 1600, 800]);
    sgtitle('第一个视频片段的5次尝试 - 最佳椭圆聚类块检测');
    
    % 遍历5次尝试
    for t = 1:5
        % ========== 数据准备 ==========
        frame_data = squeeze(segment1_attempts{t}(1, :, :, :));
        [height, width, ~] = size(frame_data);
        
        % ========== 聚类块解析 ==========
        % 将颜色量化为离散标签
        [unique_colors, ~, color_labels] = unique(reshape(frame_data, [], 3), 'rows');
        color_labels = reshape(color_labels, height, width);
        
        % ========== 椭圆检测 ==========
        best_score = -inf;
        best_mask = false(height, width);
        
        % 遍历每个颜色聚类块
        for k = 1:size(unique_colors, 1)
            % 生成当前聚类块的二值掩膜
            cluster_mask = (color_labels == k);
            
            % 跳过过小的区域
            if nnz(cluster_mask) < 50
                continue;
            end
            
            % 椭圆匹配度计算
            [current_mask, current_score] = evaluate_ellipse(cluster_mask);
            
            % 更新最佳结果
            if current_score > best_score
                best_score = current_score;
                best_mask = current_mask;
            end
        end
        
        % ========== 可视化 ==========
        % 原始聚类图像
        subplot(3, 5, t);
        imshow(frame_data);
        title(sprintf('尝试 %d - 原始聚类', t));
        
        % 椭圆区域叠加显示
        subplot(3, 5, t+5);
        imshow(frame_data);
        hold on;
        if best_score > 0
            contourf = bwboundaries(best_mask);
            for b = 1:length(contourf)
                plot(contourf{b}(:, 2), contourf{b}(:, 1), 'r', 'LineWidth', 2);
            end
        end
        hold off;
        title(sprintf('椭圆得分: %.2f', best_score));
        
        % 黑白二值图
        subplot(3, 5, t+10);
        binary_img = ones(height, width);
        binary_img(best_mask) = 0;
        imshow(binary_img);
        title('椭圆区域二值化');
    end
end

function [best_mask, best_score] = evaluate_ellipse(mask)
    % 初始化输出
    best_mask = false(size(mask));
    best_score = 0;
    
    % 连通区域分析
    labeled_mask = bwlabel(mask);
    stats = regionprops(labeled_mask, ...
        'Area', 'Eccentricity', 'Solidity', 'MajorAxisLength', 'MinorAxisLength');
    
    % 过滤无效区域
    valid_idx = find([stats.Area] >= 50 & ...          % 最小面积
                    [stats.Eccentricity] < 0.95 & ...   % 排除过于细长
                    [stats.Solidity] > 0.9);            % 排除多孔区域
    
    if isempty(valid_idx)
        return;
    end
    
    % 计算椭圆匹配度评分
    scores = zeros(1, length(valid_idx));
    for i = 1:length(valid_idx)
        idx = valid_idx(i);
        % 评分公式：考虑离心率、面积、形状规则性
        area_weight = log10(stats(idx).Area);  % 对数尺度防止大区域主导
        eccentricity_score = 1 - abs(0.7 - stats(idx).Eccentricity);  % 最佳离心率0.7
        aspect_score = 1 - abs(1 - stats(idx).MajorAxisLength/stats(idx).MinorAxisLength)/2;
        
        scores(i) = area_weight * eccentricity_score * aspect_score;
    end
    
    % 选择最佳区域
    [best_score, best_idx] = max(scores);
    best_region = valid_idx(best_idx);
    best_mask = (labeled_mask == best_region);
end
