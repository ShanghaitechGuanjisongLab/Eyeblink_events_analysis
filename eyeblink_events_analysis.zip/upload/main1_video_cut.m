% 定义输入和输出文件夹路径
inputFolder = fullfile(pwd, 'dataset1');
outputFolder = fullfile(pwd, 'dataset2');

% 确保输出文件夹存在
if ~exist(outputFolder, 'dir')
    mkdir(outputFolder);
end

% 获取所有AVI视频文件列表
videoFiles = dir(fullfile(inputFolder, '*.avi'));
if isempty(videoFiles)
    error('dataset1 中没有找到AVI文件');
end

% ========== 第一阶段：收集所有视频的坐标信息 ==========
% 创建存储坐标的结构数组
coordData = struct('name', {}, 'x_range', {}, 'y_range', {});

for k = 1:length(videoFiles)
    % 当前视频文件路径
    videoPath = fullfile(inputFolder, videoFiles(k).name);
    [~, name, ~] = fileparts(videoFiles(k).name);
    
    % 创建VideoReader对象
    v = VideoReader(videoPath);
    
    % 显示第一帧供用户选择区域
    fig = figure;
    v.CurrentTime = 0;
    firstFrame = readFrame(v);
    h_fig = imshow(firstFrame);
    title(sprintf('[坐标选择阶段] 视频 %d/%d: 请依次点击左上角和右下角', k, length(videoFiles)));
    hold on;
    
    % 交互式获取两个点
    x = zeros(2,1);
    y = zeros(2,1);
    markerSize = 2;
    lineWidth = 1;
    color = 'r';
    
    for i = 1:2
        [xi, yi] = ginput(1);
        x(i) = xi;
        y(i) = yi;
        xi = round(xi);
        yi = round(yi);
        plot([xi-markerSize, xi+markerSize], [yi, yi], 'Color', color, 'LineWidth', lineWidth);
        plot([xi, xi], [yi-markerSize, yi+markerSize], 'Color', color, 'LineWidth', lineWidth);
        drawnow;
    end
    hold off;
    
    % 处理坐标参数
    x = round(x);
    y = round(y);
    x_range = sort(x);
    y_range = sort(y);
    [rows, cols, ~] = size(firstFrame);
    x_range = [max(1, x_range(1)), min(cols, x_range(2))];
    y_range = [max(1, y_range(1)), min(rows, y_range(2))];
    
    % 存储坐标信息
    coordData(k).name = name;
    coordData(k).x_range = x_range;
    coordData(k).y_range = y_range;
    
    % 关闭当前图形
    close(fig);
end

% ========== 第二阶段：统一处理所有视频 ==========
h_main = waitbar(0, '准备开始批量处理...');

for k = 1:length(videoFiles)
    % 当前视频信息
    videoPath = fullfile(inputFolder, videoFiles(k).name);
    [~, name, ~] = fileparts(videoFiles(k).name);
    outputPath = fullfile(outputFolder, [name '_cropped.avi']);
    
    % 获取存储的坐标
    x_range = coordData(k).x_range;
    y_range = coordData(k).y_range;
    
    % 创建VideoReader和VideoWriter
    v = VideoReader(videoPath);
    outputVideo = VideoWriter(outputPath);
    outputVideo.FrameRate = v.FrameRate;
    open(outputVideo);
    
    % 更新主进度条信息
    waitbar((k-1)/length(videoFiles), h_main,...
        sprintf('正在处理视频 %d/%d: %s', k, length(videoFiles), name));
    
    % 逐帧处理
    frameCount = 0;
    totalFrames = floor(v.Duration * v.FrameRate);
    while hasFrame(v)
        frame = readFrame(v);
        croppedFrame = frame(y_range(1):y_range(2), x_range(1):x_range(2), :);
        writeVideo(outputVideo, croppedFrame);
        
        % 更新进度（改用帧数计算更准确）
        frameCount = frameCount + 1;
        waitbar(k/length(videoFiles) * (frameCount/totalFrames), h_main);
    end
    
    % 关闭资源
    close(outputVideo);
end

% 完成清理
close(h_main);
disp('所有视频处理完成！');
