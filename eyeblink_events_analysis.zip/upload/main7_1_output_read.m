%% 多数据处理器
% 查找所有EyeData开头的文件
fileList = dir('EyeData*.mat');
if isempty(fileList)
    error('未找到以EyeData开头的MAT文件');
end

% 处理每个文件
for fileIdx = 1:length(fileList)
    try
        % ===== 第一阶段：数据准备 =====
        [~, fileName] = fileparts(fileList(fileIdx).name);
        
        % 使用正则表达式提取末尾3位数字
        numMatch = regexp(fileName, '(\d{3})$', 'tokens');
        if isempty(numMatch)
            warning('跳过文件：%s（无有效数字后缀）', fileName);
            continue;
        end
        numStr = numMatch{1}{1};
        
        % 加载数据
        fileData = load(fileList(fileIdx).name);
        if ~isfield(fileData, 'outputData')
            warning('文件 %s 缺少outputData变量', fileName);
            continue;
        end
        rawData = fileData.outputData;
        
        % ===== 第二阶段：创建sq数组 =====
        sqVarName = ['sq' numStr];
        eval([sqVarName ' = rawData;']);
        fprintf('已创建变量：%s\n', sqVarName);
        
        % ===== 第三阶段：创建data数组 =====
        dataBuffer = [];
        for cellIdx = 1:numel(rawData)
            cellData = rawData{cellIdx};
            if isnumeric(cellData) && ~isempty(cellData)
                dataBuffer = [dataBuffer; cellData(:)];
            end
        end
        dataVarName = ['data' numStr];
        eval([dataVarName ' = dataBuffer;']);
        fprintf('已创建变量：%s（%d个元素）\n', dataVarName, numel(dataBuffer));
        
        % ===== 第四阶段：创建min数组 =====
        minValues = nan(numel(rawData), 1);
        for cellIdx = 1:numel(rawData)
            cellData = rawData{cellIdx};
            if isnumeric(cellData) && ~isempty(cellData)
                minValues(cellIdx) = min(cellData(:));
            end
        end
        minVarName = ['min' numStr];
        eval([minVarName ' = minValues;']);
        fprintf('已创建变量：%s（%d个最小值）\n', minVarName, numel(minValues));
        
        % ===== 第五阶段：保存到工作区 =====
        assignin('base', sqVarName, eval(sqVarName));
        assignin('base', dataVarName, eval(dataVarName));
        assignin('base', minVarName, eval(minVarName));
        
    catch ME
        warning('处理文件 %s 失败：%s', fileName, ME.message);
    end
end

disp('===== 处理完成 =====');
